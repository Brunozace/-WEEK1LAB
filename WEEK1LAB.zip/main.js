//import { halfOf, multiply } from './lib.js';
//console.log(halfOf(84));
//console.log(multiply(21, 2));
//
//import doSomething from './doSomething.js';
//doSomething();

//import { flag, touch } from './validator.js';
//console.log(flag);
//touch();
//console.log(flag);

function add(x, y = 0) {
    console.log(x + y);
}
add(1);
add(1, 2);




