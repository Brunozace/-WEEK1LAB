function add(x, y = 0) {
    console.log(x + y);
}

add(1);

add(1, 2);
