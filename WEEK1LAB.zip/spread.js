function userTopFriends(firstFriend, secondFriend, thirdFriends) {
    console.log(firstFriend);
    console.log(secondFriend);
    console.log(thirdFriends);
}

userTopFriends(...['Alice', 'Bob', 'Michelle']);
