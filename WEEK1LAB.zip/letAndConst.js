function iterateVar() {
    for (var i = 0; i < 10; i++) {
        console.log(i);
    }
    console.log(i);
}
function iterateLet() {
    for (let i = 0; i < 10; i++) {
        console.log(i);
    }
    console.log(i);
} //throws error

const me = 1;
me = 2; //will throw error
